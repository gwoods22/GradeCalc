# GradeCalc
Chrome Extension that calculates GPA for McMaster University students using JQuery
